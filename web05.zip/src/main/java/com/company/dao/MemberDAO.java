package com.company.dao;

public interface MemberDAO {

}
