package com.company.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.company.vo.BoardVO;

@Repository
public class BoardDAOImpl implements BoardDAO {

	@Inject
	SqlSession sqlSession;
	
	/* 게시물 목록 보기(.selectList() : mybatis로 실행하여 목록으로 결과를 받기 위한 매서드) */
	@Override
	public List<BoardVO> boardList() throws Exception {
		return sqlSession.selectList("boardMapper.boardList");
	}
	
	/* 게시물 상세내용 불러오기(.selctOne(해당 mapper_id, 전달값) : 하나의 레코드를 결과로 받기 위한 매서드) */
	@Override
	public BoardVO boardRead(int seq) throws Exception {
		return sqlSession.selectOne("boardMapper.boardRead", seq);
	}
	
	/* 게시물 작성(.insert(해당 mapper_id, 전달객체) : mybatis로 DB에 하나의 레코드를 추가하기 위한 메서드) */
	@Override
	public void writerBoard(BoardVO bdvo) throws Exception {
		sqlSession.insert("boardMapper.boardWriter", bdvo);
	}

	/* 게시물 수정 */
	@Override
	public void boardUpdate(BoardVO bdvo) throws Exception {
		sqlSession.update("boardMapper.boardUpdate", bdvo);
	}

	/* 게시물 삭제 */
	@Override
	public void boardDelete(int seq) throws Exception {
		sqlSession.delete("boardMapper.boardDelete", seq);
	}
}
