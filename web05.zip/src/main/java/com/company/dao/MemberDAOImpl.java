package com.company.dao;

import org.springframework.stereotype.Repository;

@Repository
public class MemberDAOImpl implements MemberDAO {

}
