package com.company.dao;

import java.util.List;

import com.company.vo.BoardVO;

public interface BoardDAO {
	/* 게시물 목록 보기 */
	public List<BoardVO> boardList() throws Exception;
	
	/* 게시물 상세 내용 불러오기 */
	public BoardVO boardRead(int seq) throws Exception;
	
	/* 게시물 작성 */
	public void writerBoard(BoardVO bdvo) throws Exception;
	
	/* 게시물 수정 */
	public void boardUpdate(BoardVO bdvo) throws Exception;
	
	/* 게시물 삭제 */
	public void boardDelete(int seq) throws Exception;
}
