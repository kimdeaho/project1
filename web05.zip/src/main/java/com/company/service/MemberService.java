package com.company.service;

public interface MemberService {

}
