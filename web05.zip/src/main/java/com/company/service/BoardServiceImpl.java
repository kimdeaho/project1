package com.company.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.company.dao.BoardDAO;
import com.company.vo.BoardVO;

@Service
public class BoardServiceImpl implements BoardService{

	@Inject
	public BoardDAO boarddao;

	@Override
	public List<BoardVO> boardList() throws Exception {
		return boarddao.boardList();
	}

	@Override
	public BoardVO boardRead(int seq) throws Exception {
		return boarddao.boardRead(seq);
	}

	@Override
	public void writerBoard(BoardVO bdvo) throws Exception {
		boarddao.writerBoard(bdvo);
		
	}

	@Override
	public void boardUpdate(BoardVO bdvo) throws Exception {
		boarddao.boardUpdate(bdvo);
		
	}

	@Override
	public void boardDelete(int seq) throws Exception {
		boarddao.boardDelete(seq);
	}
	
}
