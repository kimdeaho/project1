package com.company.service;

public interface NoticeService {

}
