package com.company.vo;

import java.util.Date;

public class NoticeVO {
	private int seq;
	private String title;
	private String content;
	private Date resdate;
	private String wirter;
	
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getResdate() {
		return resdate;
	}
	public void setResdate(Date resdate) {
		this.resdate = resdate;
	}
	public String getWirter() {
		return wirter;
	}
	public void setWirter(String wirter) {
		this.wirter = wirter;
	}
	
	@Override
	public String toString() {
		return "NoticeVO [seq=" + seq + ", title=" + title + ", content=" + content + ", resdate=" + resdate
				+ ", wirter=" + wirter + "]";
	}
	
}
