package com.company.controller;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServlet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.company.service.BoardService;
import com.company.vo.BoardVO;

@Controller
public class BoardController extends HttpServlet {
private static final Logger logger = LoggerFactory.getLogger(BoardController.class);

	@Inject
	public BoardService service;
	
	/* 리스트 보기 */
	/* Model인 DTO를 DI하여 View로 전달 */
	@RequestMapping("/board/list")
	public String boardList(Model model) throws Exception {
		List<BoardVO> list = service.boardList();
		model.addAttribute("list",list);
		return "board/board_list";
	}
}
