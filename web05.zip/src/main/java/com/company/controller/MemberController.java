package com.company.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpServlet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;

import com.company.service.MemberService;

@Controller
public class MemberController extends HttpServlet {
private static final Logger logger = LoggerFactory.getLogger(MemberController.class);

	@Inject
	public MemberService service;
	

}
