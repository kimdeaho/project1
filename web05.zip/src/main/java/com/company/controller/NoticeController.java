package com.company.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpServlet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;

import com.company.service.NoticeService;

@Controller
public class NoticeController extends HttpServlet {
private static final Logger logger = LoggerFactory.getLogger(NoticeController.class);
	
	@Inject
	public NoticeService service;
}
