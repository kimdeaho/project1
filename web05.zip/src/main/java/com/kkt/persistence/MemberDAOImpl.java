package com.kkt.persistence;

import java.util.HashMap;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.kkt.domain.MemberVO;

@Repository
public class MemberDAOImpl implements MemberDAO {

	@Inject
	private SqlSession sql;
	
	// 매퍼 
	private static String namespace = "com.kkt.mappers.memberMapper";
	
	// 회원 가입
	@Override
	public void signup(MemberVO vo) throws Exception {
		sql.insert(namespace + ".signup", vo);
	}
	
	// 로그인 : 없는 아이디 입력으로 인한 로그인 실패시 Null값 처리 안함
	@Override
	public MemberVO signin(MemberVO vo) throws Exception {
		return sql.selectOne(namespace + ".signin", vo);
	}

	// 로그인2 : 로그인 실패시 Null값 처리함
	@Override
	public MemberVO login(HashMap<String, String> map) throws Exception {
		return sql.selectOne(namespace + ".login", map);
	}
}