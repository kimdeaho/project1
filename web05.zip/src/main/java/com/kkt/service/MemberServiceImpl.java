package com.kkt.service;

import java.util.HashMap;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import com.kkt.domain.MemberVO;
import com.kkt.persistence.MemberDAO;

@Service
public class MemberServiceImpl implements MemberService {

	@Inject
	private MemberDAO dao;

	// 회원 가입
	@Override 
	public void signup(MemberVO vo) throws Exception {
		dao.signup(vo);		
	}
	
	// 로그인 : 없는 아이디 입력으로 인한 로그인 실패시 Null값 처리 안함
	@Override
	public MemberVO signin(MemberVO vo) throws Exception {
		return dao.signin(vo);
	}

	// 로그인2 : 로그인 실패시 Null값 처리함
	@Override
	public boolean login(HttpServletRequest request) throws Exception {
		// 아이디와 비밀번호를 저장할 map 생성
		HashMap<String, String> map = new HashMap<String, String>();
		
		// 로그인 성공 여부(DB 보유 여부)
		boolean loginSuccess = false;
		
		// 필요한 데이터를 추출
		String userId = request.getParameter("userId");
		String userPw = request.getParameter("userPass");
		
		// 추출한 데이터를 map에 입력
		map.put("userId", userId);
		map.put("userPw", userPw);
		
		MemberVO login = dao.login(map);

		// login의 값이 null이 아니라면 (데이터가 존재한다면)
		if (login != null) {
			HttpSession session = request.getSession();
			// 세션에 로그인 정보를 부여함
			session.setAttribute("login", login);
			// 로그인 성공 여부를 변경
			loginSuccess = true;
		}
		return loginSuccess;
	}
	
	// 로그아웃
	@Override
	public void signout(HttpSession session) throws Exception {
		session.invalidate();
	}
} 
