package com.kkt.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.kkt.domain.MemberVO;

public interface MemberService {

	// 회원 가입
	public void signup(MemberVO vo) throws Exception;

	// 로그인 : 없는 아이디 입력으로 인한 로그인 실패시 Null값 처리 안함
	public MemberVO signin(MemberVO vo) throws Exception;
	
	// 로그인2 : 로그인 실패시 Null값 처리함
	public boolean login(HttpServletRequest request) throws Exception;
	
	// 로그아웃
	public void signout(HttpSession session) throws Exception;
}