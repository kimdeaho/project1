package kr.co.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import kr.co.vo.MemberVO;
@Repository
public class MemberDAOImpl implements MemberDAO {

	@Inject
	SqlSession sql;
	//회원 목록 조회 -> sql.memberList() MemberVO
		@Override
		public List<MemberVO> memberList() throws Exception{
			return sql.selectList("memberMapper.memberList");
		}
		
		//회원 정보 보기 -> sql.memberView(MemberVO) MemberVO
		@Override
		public MemberVO memberView(MemberVO memberVO) throws Exception{
			return sql.selectOne("memberMapper.memberView", memberVO);
		}
		
		//로그인 -> sql.login(MemberVO)
		@Override
		public MemberVO login(MemberVO memberVO) throws Exception{
			return sql.selectOne("memberMapper.login", memberVO);
			
		}
		
		//회원 가입 -> sql.register(MemberVO)
		@Override
		public void register(MemberVO memberVO) throws Exception{
			sql.insert("memberMapper.regiter",memberVO);
		}
		
		//회원 정보 수정 -> sql.memberUpdate(userid)
		@Override
		public void memberUpdate(String userid) throws Exception{
			sql.update("memberMapper.memberUpdate", userid);
		}
		
		//회원 탈퇴 -> sql.memberDelete(userid)
		@Override
		public void memberDelete(String userid) throws Exception{
			sql.delete("memberMapper.memberDelete",userid);
		}
		
		//패스워드 체크 -> passCk(userid, userpass) int
		@Override
		public int passck(MemberVO memberVO) throws Exception{
			return sql.selectOne("memberMapper.passCk", memberVO);
			
		}
		
		//아이디 중복 체크	-> idChk(id) int
		@Override
		public int idChk(MemberVO memberVO) throws Exception{
			return sql.selectOne("memberMapper.idChk", memberVO);
		}
}
