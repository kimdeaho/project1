package kr.co.dao;

import java.util.List;

import kr.co.vo.MemberVO;

public interface MemberDAO {
	//회원 목록 조회 -> sql.memberList() MemberVO
	public List<MemberVO> memberList() throws Exception;
	
	//회원 정보 보기 -> sql.memberView(MemberVO) MemberVO
	public MemberVO memberView(MemberVO memberVO) throws Exception;
	
	//로그인 -> sql.login(MemberVO)
	public MemberVO login(MemberVO memberVO) throws Exception;
	
	//회원 가입 -> sql.regiter(MemberVO)
	public void register(MemberVO memberVO) throws Exception;
	
	//회원 정보 수정 -> sql.memberUpdate(userid)
	public void memberUpdate(String userid) throws Exception;
	
	//회원 탈퇴 -> sql.memberDelete(userid)
	public void memberDelete(String userid) throws Exception;
	
	//패스워드 체크 -> sql.passCk(MemberVO) int
	public int passck(MemberVO memberVO) throws Exception;
	
	//아이디 중복 체크	-> sql.idChk(id) int
	public int idChk(MemberVO memberVO) throws Exception;
}
