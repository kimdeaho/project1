package kr.co.controller;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import kr.co.vo.MemberVO;

public class JunitTest {
	static final Logger logger = LoggerFactory.getLogger(JunitTest.class);
	//주입 테스트 안됨
	@Autowired
	MemberVO vo;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		logger.info("@BeforeClass 실행");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		logger.info("@AfterClass 실행");
	}

	@Before
	public void setUp() throws Exception {
		logger.info("@Before 실행");
//		vo.setUserid("kkt");
//		vo.setUserpw("4321");
	}

	@After
	public void tearDown() throws Exception {
		logger.info("@After 실행");
	}

	@Test(expected=RuntimeException.class) //예외 발생 클래스 지정
	public void test1() {
		logger.info("@Test 단위 테스트 케이스 실행 예외 처리");
		throw new RuntimeException();
	}
	
	@Test(timeout=1000)		//밀리세컨드 단위로 시간만료 지정
	public void test2() {
		logger.info("@Test 테스트 케이스 실행");
		MemberVO member = new MemberVO();
		member.setUserId("admin");
		member.setUserPass("1234");
		logger.info("member의 아이디 : "+member.getUserId());
		logger.info("member의 비밀번호 : "+member.getUserPass());
		
		//Assert.assertEquals("관리자", "admin",member.getUserId());
		//Assert.assertEquals("비밀번호 일치", "4321",member.getUserPass());
		//assertTrue(첫번째>두번째) : 현재 파라미터의 값이 참인지
		//assertTrue("메시지",첫번째>두번째) : 현재 파라미터의 값이 참인지
		//assertEquals("메시지",첫번째,두번째) : 두 개의 데이터가 일치하는지
		//assertNull("메시지", 객체명) : 객체나 변수가 Null인지
		//assertSame("메시지",첫번째,두번째) : 두 개의 데이터가 일치하는지
		//assertNotSame("메시지",첫번째,두번째) : 두 개의 데이터가 불일치하는지
	}
}