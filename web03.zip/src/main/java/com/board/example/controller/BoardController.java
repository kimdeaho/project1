package com.board.example.controller;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.board.example.dto.BoardDTO;
import com.board.example.service.BoardService;


@Controller
@RequestMapping("/board/*")
public class BoardController {
	@Inject
	BoardService boardService;
	
	/* 'board/list.do' */
	/*	옛날 ModelAndView : Model인 DTO로 데이터를 받아 View에 전달하는 방식
	 * @RequestMapping("list.do") 
	 * 	public ModelAndView boardMenu() throws Exception{
	 * 		List<BoardDTO> list = boardService.boardList(); 
	 * 		ModelAndView mav = new  ModelAndView(); 
	 * 		mav.setViewName("board/board_list");
	 * 		mav.addObject("list",list); 
	 * 		return mav; 
	 * }
	 */
	
	/* 리스트 보기 */
	/* Model인 DTO를 DI하여 View로 전달 */
	@RequestMapping("list.do")
	public String boardList(Model model) throws Exception {
		List<BoardDTO> list = boardService.boardList();
		model.addAttribute("list",list);
		return "board/board_list";
	}

	/* 글쓰기 폼을 표시 */
	/* writer_page를 호출하여 board/writer_page.jsp파일로 이동 */
	@RequestMapping("writer_page")
	public String writerpage() {
		return "board/writer_page";
	}

	/* 글 추가 처리 */
	/*value="insert.do", method=RequestMethod.POST -> 메소드가 post일 경우 */
	@RequestMapping(value="insert.do", method=RequestMethod.POST)
	public String boardWriter(BoardDTO bdto) throws Exception{
		boardService.writerBoard(bdto);
		return "redirect:list.do";  /* 완료 후 목록으로 리턴 */
	}

	/* 글 상세보기 */
	/* bno를 가져와서 read.do로 전송 */
	@RequestMapping(value="read.do", method=RequestMethod.GET)
	public String boardRead(@RequestParam int bno, Model model) throws Exception {
		BoardDTO data = boardService.boardRead(bno);
		model.addAttribute("data", data);
		return "board/board_read";
	}
	
	/* 글 수정페이지로 이동 */
	@RequestMapping(value="updatepage", method=RequestMethod.GET)
	public String boardUpdate(@RequestParam int bno, Model model) throws Exception{
		BoardDTO data = boardService.boardRead(bno);
		model.addAttribute("data", data);
		return "board/board_update";
	}
	
	/* 글 수정처리 */
	@RequestMapping(value="update.do", method=RequestMethod.POST)
	public String boardUpdatDo(BoardDTO bdto) throws Exception{
		boardService.boardUpdate(bdto);
		return "redirect:list.do";
	}
	
	/* 글 삭제 처리 */
	@RequestMapping(value="delete.do", method=RequestMethod.GET)
	public String boardDelete(@RequestParam int bno, Model model) throws Exception{
		boardService.boardDelete(bno);
		return "redirect:list.do";
	}
}